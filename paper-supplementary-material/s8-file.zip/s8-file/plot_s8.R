#
# This script plots saliences for species abundances and gene markers for S8 supplementary
#

library(here)

library(jsonlite)
library(stringr)
library(hash)

library(ggplot2)
library(ggpubr)

library(RcppCNPy)
library(reshape2)
library(dplyr)


# Globals  ===============================================================

# Initialize project paths
here::i_am("scripts/plot_s8.R")

# Data folders
ROOT_DATA <- here::here('data')
DIR_DATA <- file.path(ROOT_DATA, 'datasets', 'default')
DIR_SALIENCY <- file.path(ROOT_DATA, 'saliency_maps')

# Output folders
ROOT_PLOTS <- here::here('plots')
DIR_PLOTS <- file.path(ROOT_PLOTS, 's8')

# Dataset names
datasets = c(
  'Delta-Obesity',
  'Early-Colorectal-EMBL',
  'Cirrhosis',
  'IBD',
  'Obesity',
  'Obesity-joint',
  'Delta-Colorectal',
  'Colorectal-EMBL',
  'Hypertension',
  'T2D',
  'Colorectal',
  'WT2D',
  'Colorectal-YachidaS'
)
dataset <- datasets[3] # select dataset manually

# Other globals
start_row <- 211  # start data body in input dataframes
n_top_ <- 25  # default N top species to output
n_rep_experiments <- 25 # total number of repeated experiments
class_one_threshold <- 0.5  # current threshold to convert predictions to class 1
p_thr_ <- 0.1 # p-value threshold in Wilcoxon test
use_p_fdr_ <- TRUE # use results with FDR correction from Wilcoxon test
sort_mode_ <- 'Mean' # sort saliencies by mean values


# Create label dictionary for healthy/affected status in the dataset
label_dict = hash()
  # Controls
label_dict[['n']] = 0
  # Chirrhosis
label_dict[['cirrhosis']] = 1
  # Colorectal Cancer
label_dict[['cancer']] = 1 
label_dict[['small_adenoma']] = 0
  # IBD
label_dict[['ibd_ulcerative_colitis']] = 1 
label_dict[['ibd_crohn_disease']] = 1
# T2D and WT2D
label_dict[['t2d']] = 1
# Obesity / Obesity-joint
label_dict[['leaness']] = 0 
label_dict[['obesity']] = 1
# Early-Colorectal-EMBL (early = 0, I, II; late = III, IV)
label_dict[['crc_0']] = 0 
label_dict[['crc_I']] = 0
label_dict[['crc_II']] = 0
label_dict[['crc_III']] = 1
label_dict[['crc_IV']] = 1
# Colorectal-EMBL (healthy = n)
label_dict[['CRC_0']] = 1
label_dict[['CRC_I']] = 1
label_dict[['CRC_II']] = 1
label_dict[['CRC_III']] = 1
label_dict[['CRC_IV']] = 1
# Hypertension
label_dict[['Health']] = 0
label_dict[['Hypertension']] = 1
# Custom
label_dict[['sick']] = 1
# YachidaS
label_dict[['healthy']] = 0
label_dict[['CRC-0']] = 1
label_dict[['CRC-I']] = 1
label_dict[['CRC-II']] = 1
label_dict[['CRC-III']] = 1
label_dict[['CRC-IV']] = 1
label_dict[['adenoma']] = 1
label_dict[['carcinoma_surgery_history']] = 1


# Function definitions ======================================================

FancyScientific <- function(l) {
  # turn in to character string in scientific notation
  l <- gsub("0e\\+00","0",l)
  l <- format(l, scientific = TRUE)
  # quote the part before the exponent to keep all the digits
  l <- gsub("^(.*)e", "'\\1'e", l)
  # turn the 'e+' into plotmath format
  l <- gsub("e", "%*%10^", l)
  # return this as an expression
  parse(text=l)
}


GetSpeciesNames <- function(data) {
  # Get substring with species names from whole taxa branch.
  #
  # Args:
  #   data: Column of dataframe that contains taxa paths.
  #
  # Returns:
  #   Vector of strings with species names.
  
  species <- as.vector(sapply(
    data, 
    function(in_str)
      ifelse(str_split_fixed(in_str, ".s__", 2)[2] != "", 
             str_split_fixed(in_str, ".s__", 2)[2], 
             str_split_fixed(in_str, ".g__", 2)[2])))
  
  species <- str_replace_all(species, "([A-Z])_([0-9])", "\\1-\\2")
  
  species <- gsub("sp_", "sp. ", species)
  species <- gsub("CAG_", "CAG:", species)
  species_new <- gsub("_", " ", species)
  
  species_new <- str_replace_all(species_new, "([0-9]) ([0-9])", "\\1_\\2")
  species_new <- str_replace_all(species_new, "([0-9]) ([0-9])", "\\1_\\2")
  
  return(species_new)
}


TestRepresentedSpecies <- function(df_abundance, p_thr = 0.05, use_p_fdr = TRUE) {
  # Perform Wilcoxon test to identify over- and underrepresented species.
  #
  # Args:
  #   df_abundance: Dataframe with abundances.
  #   p_thr: P-value threshold.
  #   use_p_fdr: Use adjusted p-values.
  #
  # Returns:
  #   Dataframe with statistical test results for the species.  
  
  # Split head and body
  df_header <- df_abundance[1:start_row-1, ]
  df_body <- df_abundance[start_row:nrow(df_abundance), ]
  
  # Get status of the patients
  patient_labels <- df_header[df_header[, 1]=='disease', 2:ncol(df_header)]
  patient_labels <- unlist(lapply(patient_labels, function(data) label_dict[[data]]))
  groups <- factor(patient_labels, levels = c(0, 1))
  
  # Create dataframe with summary statistics on patient groups
  #df_stats <- data.frame(row.names = str_split_fixed(df_body[, 1], ".s__", 2)[,2])
  df_stats <- data.frame(row.names = GetSpeciesNames(df_body[, 1]))
  df_stats$check_names <- df_body[, 1]
  
  # Perform Wilcoxon test
  print("Performing Wilcoxon test to find overrepresented species...")
  
  # Over-represented in affected group
  df_stats$W_greater_pval <- apply(
    df_body[, 2:ncol(df_body)], 
    MARGIN = 1, 
    FUN = function(x_line)
      wilcox.test(
        as.numeric(unlist(x_line[groups==1])),
        as.numeric(unlist(x_line[groups==0])),
        alternative = "greater"
      )$p.value
    )
  
  # Over-represented in health group
  df_stats$W_less_pval <- apply(
    df_body[, 2:ncol(df_body)],
    MARGIN = 1,
    FUN = function(x_line)
      wilcox.test(
        as.numeric(unlist(x_line[groups==1])),
        as.numeric(unlist(x_line[groups==0])),
        alternative = "less"
      )$p.value
    )                    
  
  # Two-side test
  df_stats$W_twoside_pval <- apply(
    df_body[, 2:ncol(df_body)],
    MARGIN = 1,
    FUN = function(x_line)
      wilcox.test(
        as.numeric(unlist(x_line[groups==0])),
        as.numeric(unlist(x_line[groups==1])),
        alternative = "two.sided"
      )$p.value
    )                    
  
  # Adjust W-test p-values for multiple comparisons
  df_stats$W_gt_pval_fdr <- p.adjust(df_stats$W_greater_pval, method = "fdr")
  df_stats$W_ls_pval_fdr <- p.adjust(df_stats$W_less_pval, method = "fdr")
  df_stats$W_twoside_pval_fdr <- p.adjust(df_stats$W_twoside_pval, method = "fdr")
  
  # Columns with colors for over- and under-represented species
  if (use_p_fdr == TRUE) {
    df_stats$representation <- 
      if_else(
        df_stats$W_gt_pval_fdr < p_thr, "Significantly more abundant \nin affected",
                  if_else(df_stats$W_ls_pval_fdr < p_thr, "Significantly more abundant \nin healthy", "Not significant")
      )
  } else {
    df_stats$representation <- 
      if_else(
        df_stats$W_greater_pval < p_thr, "Significantly more abundant \nin affected",
                  if_else(df_stats$W_less_pval < p_thr, "Significantly more abundant \nin healthy", "Not significant")
      )
  }
  
  return(df_stats)
}


# Start plotting ======================================================

#  Create output folders for plots if not exists
dir.create(ROOT_PLOTS)
dir.create(DIR_PLOTS)

# Operate with species abundances --------------------------------

for (dataset in datasets) {
  # Create dataset directory if not exists
  dir.create(file.path(DIR_PLOTS, dataset))

  # Calculate under- and over-represented species
  in_filename <- file.path(DIR_DATA, "abundance", paste("abundance_", dataset, ".txt", sep = ""))
  df_abundance <- read.csv(in_filename, sep="\t")
  df_stats <- TestRepresentedSpecies(df_abundance, p_thr = p_thr_, use_p_fdr = use_p_fdr_)
  
  print(paste("Plot saliences of species abundances for dataset", dataset))

  fname <- file.path(DIR_SALIENCY, dataset, "full_abundance_saliency_.npy")
  if (file.exists(fname)) {
    print("Generate plots from full saliency maps.")
    
    df_full_saliencies <- as.data.frame(npyLoad(fname))
    colnames(df_full_saliencies) <- GetSpeciesNames(df_abundance[start_row:nrow(df_abundance),1])
    dim_saliency_map <- dim(df_full_saliencies)
    print(paste("Dimension of saliency map:", dim_saliency_map[[1]], "x", dim_saliency_map[[2]]))
    
    fname_labels <- file.path(DIR_SALIENCY, dataset, "full_labels_.npy")
    df_full_labels <- as.data.frame(npyLoad(fname_labels))
    
    fname_predictions <- file.path(DIR_SALIENCY, dataset, "full_predictions_.npy")
    df_full_predictions <- as.data.frame(npyLoad(fname_predictions))
    
    # Convert predictions to 0/1 labels
    df_full_predictions_lb_ <- df_full_predictions
    df_full_predictions_lb_[] <- lapply(
      df_full_predictions_lb_, function(x) ifelse(x>class_one_threshold, 1, 0))
    
    # Get all true positive experiments
    tp_experiments_ind <- which(c(df_full_predictions_lb_)$V1 == c(df_full_labels)$V1, arr.ind = TRUE)
    df_tp_saliences <- df_full_saliencies[tp_experiments_ind,]
  
    # Calculate summary statistics
    df_melt <- melt(df_tp_saliences, id.vars = NULL)
  
    df_mean_summr <- aggregate(df_melt[, 2], list(df_melt$variable), mean)
    df_se_summr <- aggregate(df_melt[, 2], list(df_melt$variable), function(x) sqrt(var(x)/length(x)))
    
    df_mean_summr <- merge(df_mean_summr, df_se_summr, by.x = 1, by.y = 1, all.x = TRUE, all.y = FALSE) 
    df_summr <- merge(df_mean_summr, df_stats['representation'], by.x = 1, by.y = 0, all.x = TRUE, all.y = FALSE)
    
    colnames(df_summr) <- c('species', 'mean', 'se', 'representation')
    
    # Save ordered list of species to CSV
    # write.table(
    #   df_summr[order(df_summr$mean, decreasing = TRUE), ], 
    #   file.path(DIR_PLOTS, dataset, paste("abundance_TP_saliencies_no_rescale_pval-", p_thr_, ".csv", sep = "")), 
    #   row.names=FALSE, sep = "\t", quote = FALSE)
    
    # Select only top species
    df_summr <- df_summr[order(df_summr$mean, decreasing = TRUE), ][1:n_top_,]

    # Draw barplot for saliences ------------------------------
    
    p_barplot_err <- ggplot(
      df_summr,
      aes(x = reorder(species, mean), y = mean, fill = representation)
    ) +
    geom_col(aes(), width = 0.7) + 
    geom_errorbar(
      aes(ymin = mean - se, ymax = mean + se), width = .2, position = position_dodge(.9)
    ) +
    scale_fill_manual("", values = c(
      "Significantly more abundant \nin affected" = "blue", 
      "Significantly more abundant \nin healthy" = "brown",
      "Not significant" = "grey")) + 
    labs(
      title = paste("Mean saliences of species abundances"),
      subtitle = paste(dataset, "dataset, true positives"), 
      x = paste("Top", n_top_, "species"), 
      y = "Saliency",
    ) +
    theme_bw() +
    theme(
      plot.margin = margin(2, 1, 0, 1, unit = 'line'),
      plot.title = element_text(hjust = 0.5, size = 16),# face= "bold"), 
      plot.title.position = "plot",
      plot.subtitle = element_text(hjust = 0.5, size = 14), 
      # legend
      legend.position = "right",
      legend.text=element_text(size=12),
      legend.key.size = unit(1.0, "lines"),
      legend.title = element_text(face= "bold"),
      # axis
      axis.line = element_blank(),
      axis.title = element_text(size=14),
      axis.text = element_text(size=12, face= "italic")
    ) + 
    coord_flip() +
    scale_y_continuous(labels=FancyScientific)
    
    p_barplot_err
    
    fname <- file.path(DIR_PLOTS, dataset, paste("abundance_errbarplot_TP_saliences_no_rescale_pval-", p_thr_, ".png", sep = ""))
    ggsave(p_barplot_err, width = 12, height = 8, dpi = 300, bg = 'white', filename = fname)
    print(paste("Barplots from TP saliency map saved into", fname))
  }
}

# Operate with gene markers --------------------------------------------------

for (dataset in datasets) {
  # Create dataset directory if not exists
  dir.create(file.path(DIR_PLOTS, dataset))
  
  print(paste("Load files with gene marker data for dataset", dataset))
  fname_markers <- file.path(DIR_DATA, "marker", paste("marker_", dataset, ".txt", sep = ""))
  fname <- file.path(DIR_SALIENCY, dataset, "full_markers_saliency_.npy")
  
  print(paste("Plot saliences of gene markers for dataset", dataset))
  if (file.exists(fname_markers) & file.exists(fname)) {
    print("Generate marker plots from full saliency maps.")
    
    df_markers <- read.csv(fname_markers, sep="\t")
    df_full_saliencies <- as.data.frame(npyLoad(fname))
    colnames(df_full_saliencies) <- df_markers[start_row:nrow(df_markers),1]
    dim_saliency_map <- dim(df_full_saliencies)
    print(paste("Dimension of saliency map:", dim_saliency_map[[1]], "x", dim_saliency_map[[2]]))
    
    fname_labels <- file.path(DIR_SALIENCY, dataset, "full_labels_.npy")
    df_full_labels <- as.data.frame(npyLoad(fname_labels))
    
    fname_predictions <- file.path(DIR_SALIENCY, dataset, "full_predictions_.npy")
    df_full_predictions <- as.data.frame(npyLoad(fname_predictions))
    
    # Convert predictions to 0/1 labels
    df_full_predictions_lb_ <- df_full_predictions
    df_full_predictions_lb_[] <- lapply(
      df_full_predictions_lb_, function(x) ifelse(x>class_one_threshold, 1, 0))
    
    # Get all true positive experiments
    tp_experiments_ind <- which(c(df_full_predictions_lb_)$V1 == c(df_full_labels)$V1, arr.ind = TRUE)
    df_tp_saliences <- df_full_saliencies[tp_experiments_ind,]
    
    # Select top markers
    df_saliencies_summary <- as.data.frame(t(do.call(cbind, lapply(df_tp_saliences, summary))))
    df_saliencies_summary <- df_saliencies_summary[order(df_saliencies_summary[,'Mean'], decreasing = TRUE),]
    
    # Save ordered list of markers into CSV 
    # write.table(
    #   df_saliencies_summary['Mean'], file.path(DIR_PLOTS, dataset, paste("marker_TP_saliencies_no_rescale.csv", sep = "")), 
    #   row.names=TRUE, sep = "\t", quote = FALSE, col.names = NA)
    
    # Select top species with highest mean saliencies
    top_species <- row.names(df_saliencies_summary[1:n_top_,])
    
    # Calculate summary statistics
    df_melt <- melt(df_tp_saliences[,top_species], id.vars = NULL)
    df_mean_summr <- aggregate(df_melt[, 2], list(df_melt$variable), mean)
    df_se_summr <- aggregate(df_melt[, 2], list(df_melt$variable), function(x) sqrt(var(x)/length(x)))
    
    df_summr <- merge(df_mean_summr, df_se_summr, by.x = 1, by.y = 1, all.x = TRUE, all.y = FALSE)
    colnames(df_summr) <- c('species', 'mean', 'se')
    
    # Draw barplot for marker saliences --------------------------------------
    
    p_barplot_err <- ggplot(
      df_summr,
      aes(x = reorder(species, mean), y = mean, fill = mean)
    ) +
    geom_col(aes(), width = 0.7) + 
    geom_errorbar(
      aes(ymin = mean - se, ymax = mean + se), width = .2, position = position_dodge(.9)
    ) +
    labs(
      title = paste("Mean saliences of gene markers"),
      subtitle = paste(dataset, "dataset, true positives"),
      x = paste("Top", n_top_, "markers"), 
      y = "Saliency"
    ) +
    theme_bw() +
    theme(
      plot.margin = margin(2, 1, 0, 1, unit = 'line'),
      plot.title = element_text(hjust = 0.5, size = 16),
      plot.title.position = "plot",
      plot.subtitle = element_text(hjust = 0.5, size = 14), 
      # legend
      legend.position = "none",
      # axis
      axis.line = element_blank(),
      axis.title = element_text(size=14),
      axis.text = element_text(size=12),
      axis.text.y = element_text(size=11)
    ) + 
    coord_flip() +
    scale_y_continuous(labels=FancyScientific)
    
    p_barplot_err  
    
    fname <- file.path(DIR_PLOTS, dataset, paste("markers_errbarplot_TP_saliences_no_rescale.png", sep = ""))
    ggsave(p_barplot_err, width = 12, height = 8, dpi = 300, bg = 'white', filename = fname)
    print(paste("Barplots plot from TP markers saliency map saved into", fname))
  }
}


