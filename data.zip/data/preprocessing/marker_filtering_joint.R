################################################################################
## Pre-processing of marker data from DeepMicro dataset                       ##
################################################################################

# Load required packages 

library(statmod)
library(matrixStats)
library(hash)
library(questionr)

# Global constants

#ROOT_DIR <- "/mnt/container-nle-microbiome/data/deepmicro"
ROOT_DIR <- "/Users/nle5293/Documents/1-Projects/1-Microbiome/Repos/preprocessing/joint_data"

#alpha_thresholds <- c(0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8)
alpha_thresholds <- c(0.1)

# Create label dictionary for healthy/affected status in the dataset

label_dict = hash()
  # Controls
label_dict[['n']] = 0
  # Chirrhosis
label_dict[['cirrhosis']] = 1
  # Colorectal Cancer
label_dict[['cancer']] = 1
label_dict[['small_adenoma']] = 0
  # IBD
label_dict[['ibd_ulcerative_colitis']] = 1
label_dict[['ibd_crohn_disease']] = 1
  # T2D and WT2D
label_dict[['t2d']] = 1
  # Obesity
label_dict[['leaness']] = 0
label_dict[['obesity']] = 1


# Define functions -------------------------------------------------------------


do_binom_z_test <- function(p1, p2, N1, N2) {
  # Z-test that checks the equality of mean in two samples from binomial distributions.
  # p1, p2 - probabilities of successes in sample 1 and sample 2
  # N1, N2 - sizes of sample 1 and sample 2
  p <- (N1*p1 + N2*p2)/(N1 + N2)
  z_score <- (p1 - p2)/sqrt(p*(1 - p)*(1/N1 + 1/N2))
  p_val <- 2.0*(1.0 - pnorm(abs(z_score)))
  
  return(list("z" = z_score, "p_val" = p_val))
}


do_odds_ratio_test <- function(markers, labels) {
  # Odds ratio test for the strength of the association between 
  # presence of a marker and the health status of individuals. 
  # markers - marker data 
  # labels - vector of factors that label patients into healthy/affected groups
  
  markers_summary <- tapply(markers, labels, function(x) c(sum(x == 0), sum(x == 1)))
  contingency_table <- matrix(unlist(markers_summary), ncol = 2, byrow = TRUE)
  
  return(odds.ratio(contingency_table))
}


# Load data --------------------------------------------------------------------

# Set up working directory
setwd(ROOT_DIR)

# Create directory to store filtered markers
dir.create(file.path(ROOT_DIR, "marker_filtered"), showWarnings = FALSE)
dir.create(file.path(ROOT_DIR, "marker_filtered/stats"), showWarnings = FALSE)

# Number of rows to skip while reading data from files
start_row = 210

# Iterate over datasets --------------------------------------------------------

diseases = c('Cirrhosis', 'Colorectal', 'IBD', 'Obesity', 'T2D', 'WT2D')

in_filename <- paste("marker/marker_", diseases[1], ".csv", sep="")
markers <- read.csv(file = in_filename, sep = ",", header = TRUE, as.is = TRUE)
dataset_name <- rep(diseases[1], ncol(markers)-1)

for (disease in diseases[2:length(diseases)]) {
  print(paste("Read data for", disease))
  
  in_filename <- paste("marker/marker_", disease, ".csv", sep="")
  df_disease <- read.csv(file = in_filename, sep = ",", header = TRUE, as.is = TRUE)
  
  markers <- cbind(markers, df_disease[, 2:ncol(df_disease)])
  dataset_name <- c(dataset_name, rep(disease, ncol(df_disease)-1))
}
  
  
markers_header <- markers[1:start_row-1, ]
markers_body <- markers[start_row:nrow(markers), ]

# Get status of the patients

patient_labels <- markers_header[markers_header[, 1]=='disease', 2:ncol(markers_header)]
patient_labels <- unlist(lapply(patient_labels, function(data) label_dict[[data]]))

groups <- factor(patient_labels, levels = c(0, 1))

# Create dataframe with summary statistics on patient groups
df_stats <- data.frame(ID = markers_body[, 1],
                       Mean_Neg = rowMeans(data.matrix(markers_body[, 1+which(groups == 0)])), 
                       Mean_Pos = rowMeans(data.matrix(markers_body[, 1+which(groups == 1)])),                   
                       Std_Neg = rowSds(data.matrix(markers_body[, 1+which(groups == 0)])),
                       Std_Pos = rowSds(data.matrix(markers_body[, 1+which(groups == 1)])),
                       n_Neg = ncol(markers_body[, 1+which(groups == 0)]), 
                       n_Pos = ncol(markers_body[, 1+which(groups == 1)]))

df_stats$Mean_Diff <- abs(df_stats$Mean_Neg - df_stats$Mean_Pos)


# Perform Z-test for equality of means in two groups

print("Performing Z-tests...")

start_time <- Sys.time()

z_stats <- apply(data.matrix(df_stats), 
                 MARGIN = 1, 
                 FUN = function(marker_stat) do_binom_z_test(marker_stat[2], marker_stat[3], marker_stat[6], marker_stat[7]))
z_stats <- matrix(unlist(z_stats), ncol = 2, byrow = TRUE)

end_time <- Sys.time()

print(paste("Z-statistics calculated, t =", end_time - start_time, "sec"))

# Add results of Z-test into summary dataframe
df_stats$Z_score <- z_stats[, 1]
df_stats$Z_pval <- z_stats[, 2]

# Adjust Z-test p-values for multiple comparisons
df_stats$Z_pval_fdr <- p.adjust(df_stats$Z_pval, method = "fdr")
df_stats$Z_pval_holm <- p.adjust(df_stats$Z_pval, method = "holm")
#df_stats$Z_pval_hommel <- p.adjust(df_stats$Z_pval, method = "hommel")


# Perform odds ratio test for association of marker presence and disease status

print("Performing Odds ratio tests...")

start_time <- Sys.time()

or_stats <- apply(markers_body[, 2:ncol(markers_body)], 
                  MARGIN = 1, 
                  FUN = function(x_line) do_odds_ratio_test(as.numeric(unlist(x_line)), groups))
or_stats <- matrix(unlist(or_stats), ncol = 4, byrow = TRUE)

end_time <- Sys.time()

print(paste("OR-statistics calculated, t =", end_time - start_time, "sec"))

# Add results of odds ratio test into summary dataframe
df_stats$OR <- or_stats[, 1]
df_stats$OR_pval <- or_stats[, 4]
df_stats$OR_pval_fdr <- p.adjust(df_stats$OR_pval, method = "fdr") 


# Save filtered file with markers --------------------------------------------

print("Saving results")

# Save file with statistics
out_filename <- paste("marker_filtered/stats/marker_", disease, "_stat.csv", sep="")
write.csv(df_stats, out_filename, row.names = FALSE)


# Save file with filtered markers
for (alpha in alpha_thresholds) {
  markers_body_filtered <- markers_body[markers_body[, 1] %in% df_stats[df_stats$OR_pval_fdr < alpha, ]$ID, ]
  
  out_filename <- paste("marker_filtered/marker_", "joint", "_filtered_OR_p_fdr_", alpha, ".csv", sep="")
  write.table(rbind(markers_header, markers_body_filtered), out_filename, row.names = FALSE, sep = "\t", quote = FALSE) 
  
  # Write result for each dataset separatly
  markers_filtered <- rbind(markers_header, markers_body_filtered)
  df_row_names <- data.frame(markers_filtered[, 1])
  
  for (disease in diseases) {
  
    out_filename <- paste("marker_filtered/marker_", disease, "_filtered_OR_p_fdr_", alpha, ".csv", sep="")
    write.table(cbind(df_row_names, markers_filtered[, 1+which(dataset_name==disease)]), out_filename, row.names = FALSE, sep = ",", quote = FALSE) 
  }
}


